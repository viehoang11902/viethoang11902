function Giai()
{
var a = document.getElementById("txt_a").value;
var b = document.getElementById("txt_b").value;
var c = document.getElementById("txt_c").value;
a = parseFloat(a);
b = parseFloat(b);
c = parseFloat(c);
    var delta = b*b - 4*a*c;
    if(delta==0){
        var x1= -b/2*a;
        var x2= -b/2*a;
        document.getElementById("text1").innerHTML = " Nghiệm x1 là: "
        document.querySelector('#nghiem1').innerHTML = x1;
        document.getElementById("text2").innerHTML = " Nghiệm x2 là: "
        document.querySelector('#nghiem2').innerHTML = x2;
    }else if(delta > 0)
    {
        var x1= (-b + Math.sqrt(delta))/(2*a);
        var x2= (-b - Math.sqrt(delta))/(2*a);
        document.getElementById("text1").innerHTML = " Nghiệm x1 là: "
        document.querySelector('#nghiem1').innerHTML = x1;
        document.getElementById("text2").innerHTML = " Nghiệm x2 là: "
        document.querySelector('#nghiem2').innerHTML = x2;
    }else 
    {
        document.getElementById("text3").innerHTML = " Phương trình vô nghiệm!!!"
    }
}
function Xoa()
{
    document.removeChild(txt_a);
    document.removeChild(txt_b);
    document.removeChild(txt_c);
    document.removeChild(text1);
    document.removeChild(text2);
    document.removeChild(text3);
    document.removeChild(nghiem1);
    document.removeChild(nghiem2);
}
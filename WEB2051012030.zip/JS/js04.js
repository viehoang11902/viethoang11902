function Cong()
{
    var x = document.getElementById("txt_a").value;
    var y = document.getElementById("txt_b").value;
    x = parseFloat(x);
    y = parseFloat(y);  
    var tong = x + y;
    document.querySelector('#kq').innerHTML = tong;
}function Tru()
{
    var x = document.getElementById("txt_a").value;
    var y = document.getElementById("txt_b").value;
    x = parseFloat(x);
    y = parseFloat(y);  
    var tru = x - y;
    document.querySelector('#kq').innerHTML = tru;
}function Nhan()
{
    var x = document.getElementById("txt_a").value;
    var y = document.getElementById("txt_b").value;
    x = parseFloat(x);
    y = parseFloat(y);  
    var nhan = x * y;
    document.querySelector('#kq').innerHTML = nhan;
}function Chia()
{
    var x = document.getElementById("txt_a").value;
    var y = document.getElementById("txt_b").value;
    x = parseFloat(x);
    y = parseFloat(y);  
    var chia = x / y;
    document.querySelector('#kq').innerHTML = chia;
}
function Chon(){
    var x = document.getElementById("txt_a").value;
    var y = document.getElementById("txt_b").value;
var checkbox = document.getElementsByName('pheptinh');
var result = "";
for (var i = 0; i < checkbox.length; i++){
    if (checkbox[i].checked === true){
        var chon1 = i;
    }
}
switch (chon1) {
    case 0:
        Cong(x,y);
        break;
    case 1:
        Tru(x,y);
        break;
    case 2:
        Nhan(x,y);
        break;
    case 3:
        Chia(x,y);
        break;
    default:
        break;
}
}
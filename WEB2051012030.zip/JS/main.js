function TinhTong(){
   var today = new Date();
   var yearnow = today.getFullYear();
   var ten = document.getElementById("txt_x").value;
   var year = document.getElementById("txt_y").value;
    //2. chuyển kiểu dữ liệu về dạng số
    y = parseFloat(year);
   //3. tính toán
   var tuoi = yearnow - year ;
   //4. đưa giá trị tổng vào trong thẻ div kq.
   document.getElementById("text1").innerHTML = "Chào bạn, ";
   document.querySelector('#tenho').innerHTML = ten;
   document.getElementById("text2").innerHTML = "Tuổi của bạn là: ";
   document.querySelector('#kq').innerHTML = tuoi;
   //5. Gọi hàm tính tổng ở thuộc tính onClick trên nut bấm. 
} 
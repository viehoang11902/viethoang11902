function Dangky() {
    var a = document.getElementById("username").value;
    var b = document.getElementById("password").value;
    var c = document.getElementById("birthday").value;
    document.getElementById("text1").innerHTML = " Chào mừng  "
    document.querySelector('#kq1').innerHTML = a;
    document.getElementById("text5").innerHTML = " Bạn sinh ngày  "
    document.querySelector('#kq3').innerHTML = c;
    var cd = b.length;
    document.getElementById("text3").innerHTML = " Mật khẩu của bạn có "
    document.querySelector('#kq2').innerHTML = cd;
    document.getElementById("text4").innerHTML = " kí tự"
    var checkbox = document.getElementsByName('sex');
    var result = "";
    for (var i = 0; i < checkbox.length; i++){
    if (checkbox[i].checked === true){
        var chon1 = i;
     }
    }
    switch (chon1) {
        case 0:
            document.getElementById("text2").innerHTML = " Bạn là Nam. "
            break;
        case 1:
            document.getElementById("text2").innerHTML = " Bạn là Nữ. "
            break;
        default:
            break;
    }
    var select = document.getElementById("vande");
    var value = select.options[select.selectedIndex].value;
    if (value === 'kte'){
        document.getElementById("text6").innerHTML = " Vấn đề bạn quan tâm là Kinh Tế ";
    }
    else if (value === 'tthao'){
        document.getElementById("text6").innerHTML = " Vấn đề bạn quan tâm là Thể thao ";}
    else if (value === 'vanhoanghethuat'){
        document.getElementById("text6").innerHTML = " Vấn đề bạn quan tâm là Van Hoá ";
    }
}